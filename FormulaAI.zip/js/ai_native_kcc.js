/* ============================================================
   AI Native KCC — deck router + glass engine (vanilla)
   색수차 트래킹은 mapis glass_engine.js 의 glassTrack 패턴 이식
   ============================================================ */
(function () {
    'use strict';

    /* ── 페이지 순서 ── */
    var ORDER = ['pgIntro', 'pgHub', 'pgF', 'pgM'];
    var cur = 0;

    function pad(n) { return n < 10 ? '0' + n : '' + n; }

    var busy = false;
    function show(idx) {
        if (idx < 0 || idx >= ORDER.length || busy) return;
        var prev = document.querySelector('.page.on');
        var pg = document.getElementById(ORDER[idx]);
        cur = idx;

        var no = pg.querySelector('.pageNo');
        if (no) no.innerHTML = '<b>' + pad(cur - 1) + '</b> / ' + pad(ORDER.length - 2);
        document.body.classList.toggle('onIntro', ORDER[cur] === 'pgIntro');
        document.body.classList.toggle('onHub', ORDER[cur] === 'pgHub');
        if (prev === pg) return;

        function reveal() {
            pg.classList.add('on');
            pg.scrollTop = 0;
            busy = false;
            runCounters(pg);
        }
        if (prev && document.startViewTransition) {
            /* 로고(hero-logo)가 페이지 간 위치·크기 모핑 */
            busy = true;
            var vt = document.startViewTransition(function () {
                prev.classList.remove('on', 'off', 'noAnim');
                pg.classList.add('noAnim');
                reveal();
            });
            vt.finished.then(function () { busy = false; }, function () { busy = false; });
        } else if (prev) {
            busy = true;
            prev.classList.add('off');
            setTimeout(function () {
                prev.classList.remove('on', 'off', 'noAnim');
                reveal();
            }, 420);
        } else {
            reveal();
        }
    }

    function goId(id) {
        var idx = ORDER.indexOf(id);
        if (idx >= 0) show(idx);
    }

    /* ── 클릭 네비 (data-go / data-modal) — 인트로에선 유성 나선 흡입 → 플래시 → 전환 ── */
    var launching = false;
    document.addEventListener('click', function (e) {
        var closer = e.target.closest('[data-close]');
        if (closer) { closeModal(); return; }
        var opener = e.target.closest('[data-modal]');
        if (opener) { openModal(opener.getAttribute('data-modal'), opener.getAttribute('data-focus')); return; }
        var el = e.target.closest('[data-go]');
        if (!el) return;
        var id = el.getAttribute('data-go');
        if (ORDER[cur] !== 'pgIntro') { goId(id); return; }
        if (launching) return;
        launching = true;
        var intro = document.getElementById('pgIntro');
        var flash = document.getElementById('introFlash');
        intro.classList.add('launch');
        setTimeout(function () { flash.classList.add('go'); }, 870);
        setTimeout(heroToHub, 1030);
        setTimeout(function () {
            intro.classList.remove('launch');
            flash.classList.remove('go');
            launching = false;
        }, 2000);
    });

    /* ── 히어로 트랜지션: 로고 모핑 + 카드 플립X (View Transitions API) ── */
    function heroToHub() {
        var intro = document.getElementById('pgIntro');
        var hub = document.getElementById('pgHub');
        function swap() {
            intro.classList.remove('on');
            hub.classList.add('on', 'noAnim');
            hub.scrollTop = 0;
            cur = ORDER.indexOf('pgHub');
            document.body.classList.remove('onIntro');
            document.body.classList.add('onHub');
            runCounters(hub);
        }
        if (document.startViewTransition) document.startViewTransition(swap);
        else swap();
    }
    /* ── 영역 분류 뱃지 — data-modal 기준 자동 삽입 ── */
    var DOM_TAGS = {
        mData: { t: 'DATA', c: 'blue' },
        mRecog: { t: '배합추천', c: 'green' },
        mStory: { t: '배합추천', c: 'green' },
        mStory2: { t: '최적배합', c: 'purple' },
        mStory3: { t: '개념', c: 'teal' },
        mOptimal: { t: '최적배합', c: 'purple' },
        mPlan: { t: '향후계획', c: 'pink' },
        mConcept: { t: '개념', c: 'teal' },
        mRel: { t: '신뢰도', c: 'green' },
        mScope: { t: '범위', c: 'orange' },
        mScen: { t: '시스템', c: 'purple' }
    };
    Array.prototype.forEach.call(document.querySelectorAll('.bento .cell[data-modal]'), function (c) {
        var info = DOM_TAGS[c.getAttribute('data-modal')];
        if (!info) return;
        var s = document.createElement('span');
        s.className = 'domTag dt-' + info.c;
        s.textContent = info.t;
        c.appendChild(s);
    });

    /* ── 숫자 카운트업 — .num 의 첫 텍스트가 순수 숫자면 0부터 상승 ── */
    function animateNum(el, delay) {
        if (el.hasAttribute('data-nocount')) return;
        var node = el.firstChild;
        if (!node || node.nodeType !== 3) return;
        if (!el.dataset.target) el.dataset.target = node.nodeValue.trim();
        var raw = el.dataset.target;
        if (!/^[−-]?[\d,]+(\.\d+)?$/.test(raw)) return;
        if (el.dataset.counting === '1') return;
        el.dataset.counting = '1';
        var neg = /^[−-]/.test(raw);
        var numStr = raw.replace(/^[−-]/, '').replace(/,/g, '');
        var target = parseFloat(numStr);
        var decimals = (numStr.split('.')[1] || '').length;
        var hasComma = raw.indexOf(',') >= 0;
        var dur = 1100;
        var start = null;
        function fmt(v) {
            var s = v.toFixed(decimals);
            if (hasComma) {
                var parts = s.split('.');
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                s = parts.join('.');
            }
            return (neg ? '−' : '') + s;
        }
        function step(ts) {
            if (!start) start = ts;
            var p = Math.min(1, (ts - start) / dur);
            var e = 1 - Math.pow(1 - p, 3);
            node.nodeValue = fmt(target * e);
            if (p < 1) requestAnimationFrame(step);
            else el.dataset.counting = '';
        }
        setTimeout(function () { requestAnimationFrame(step); }, delay || 0);
    }
    function runCounters(pg) {
        Array.prototype.forEach.call(pg.querySelectorAll('.bento .num'), function (el) {
            /* 카드 flipInX 등장(0.9s + 셀순서*0.07s, 0.75s)에 맞춰 — 카드가 일어선 직후 카운트 시작 */
            var cell = el.closest('.cell');
            var idx = cell ? Array.prototype.indexOf.call(cell.parentElement.children, cell) : 0;
            animateNum(el, 1350 + idx * 70);
        });
        /* 허브 카드 스탯 — 카드 플립 직후 카운트 */
        Array.prototype.forEach.call(pg.querySelectorAll('.hubCards .hcStat .v'), function (el) {
            var card = el.closest('.hubCard');
            var idx = card ? Array.prototype.indexOf.call(card.parentElement.children, card) : 0;
            animateNum(el, 750 + idx * 200);
        });
    }


    /* ── 만화 캐러셀 (스토리 모달 공용) ── */
    function storyGo(m, i) {
        if (!m) return;
        var panels = m.querySelectorAll('.sPanel');
        var dots = m.querySelectorAll('.sDot');
        if (i < 0 || i >= panels.length) return;
        m._sIdx = i;
        Array.prototype.forEach.call(panels, function (p, j) { p.classList.toggle('cur', j === i); });
        Array.prototype.forEach.call(dots, function (d, j) { d.classList.toggle('on', j === i); });
        var prev = m.querySelector('.sPrev');
        var next = m.querySelector('.sNext');
        if (prev) prev.disabled = i === 0;
        if (next) next.disabled = i === panels.length - 1;
    }
    document.addEventListener('click', function (e) {
        var el;
        if ((el = e.target.closest('.sPrev'))) { var m1 = el.closest('.modalWrap'); storyGo(m1, (m1._sIdx || 0) - 1); return; }
        if ((el = e.target.closest('.sNext'))) { var m2 = el.closest('.modalWrap'); storyGo(m2, (m2._sIdx || 0) + 1); return; }
        if ((el = e.target.closest('.sDot'))) {
            var dots = Array.prototype.slice.call(el.parentElement.children);
            storyGo(el.closest('.modalWrap'), dots.indexOf(el));
            return;
        }
        if ((el = e.target.closest('.sPanel'))) { var m3 = el.closest('.modalWrap'); storyGo(m3, (m3._sIdx || 0) + 1); }
    });

    /* ── 모달 (fid: 진입 카드 관련 항목 하이라이트 · 스택: 모달 위 서브 모달 지원) ── */
    var modalStack = [];
    function openModal(id, fid) {
        var m = document.getElementById(id);
        if (!m) return;
        m.classList.add('open');
        modalStack = modalStack.filter(function (x) { return x !== id; });
        modalStack.push(id);
        if (m.querySelector('.sPanel')) storyGo(m, 0);
        var box = m.querySelector('.modalBox');
        if (box) box.scrollTop = 0;
        if (!fid) return;
        var t = m.querySelector('[data-fid="' + fid + '"]');
        if (!t) return;
        setTimeout(function () {
            t.scrollIntoView({ block: 'center', behavior: 'smooth' });
            t.classList.remove('focusPulse');
            void t.offsetWidth;
            t.classList.add('focusPulse');
            setTimeout(function () { t.classList.remove('focusPulse'); }, 2100);
        }, 550);
    }
    function closeModal() {
        while (modalStack.length) {
            var m = document.getElementById(modalStack.pop());
            if (m && m.classList.contains('open')) { m.classList.remove('open'); return; }
        }
        var f = document.querySelector('.modalWrap.open');
        if (f) f.classList.remove('open');
    }

    /* ── 키보드 ── */
    document.addEventListener('keydown', function (e) {
        var openM = document.querySelector('.modalWrap.open');
        if (openM) {
            var isStory = !!openM.querySelector('.sPanel');
            if (e.key === 'Escape') closeModal();
            else if (isStory && (e.key === 'ArrowRight' || e.key === ' ')) { e.preventDefault(); storyGo(openM, (openM._sIdx || 0) + 1); }
            else if (isStory && e.key === 'ArrowLeft') { e.preventDefault(); storyGo(openM, (openM._sIdx || 0) - 1); }
            return;
        }
        if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') { e.preventDefault(); show(cur + 1); }
        else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); show(cur - 1); }
        else if (e.key === 'Escape') { show(1); }
        else if (e.key === 'Home') { show(0); }
    });

    /* ── 테이블 행 글래스 오버레이 — mapis glass_engine(initGlassOverlay) 이식 ── */
    function initTableGlass(tbl) {
        /* 표가 든 박스는 행 오버레이와 중첩되므로 박스 글래스 해제 */
        var host = tbl.closest('.mCell');
        if (host) host.classList.remove('glass');
        var wrap = document.createElement('div');
        wrap.className = 'tblGlass';
        tbl.parentNode.insertBefore(wrap, tbl);
        wrap.appendChild(tbl);
        var overlay = document.createElement('div');
        overlay.className = 'glassRowOverlay';
        var caustic = document.createElement('div');
        caustic.className = 'glassCaustic';
        overlay.appendChild(caustic);
        wrap.appendChild(overlay);
        var currentRow = null;

        wrap.addEventListener('mouseover', function (e) {
            var tr = e.target.closest('tr');
            if (!tr || !wrap.contains(tr) || tr === currentRow) return;
            if (!tr.querySelector('td')) { currentRow = null; overlay.classList.remove('active'); return; } /* 헤더 행 제외 */
            currentRow = tr;
            var wr = wrap.getBoundingClientRect();
            var rr = tr.getBoundingClientRect();
            overlay.style.top = (rr.top - wr.top - 1) + 'px';
            overlay.style.left = (rr.left - wr.left) + 'px';
            overlay.style.width = rr.width + 'px';
            overlay.style.height = (rr.height - 1) + 'px';
            overlay.classList.add('active');
        });
        wrap.addEventListener('mousemove', function (e) {
            if (!currentRow) return;
            var olRect = overlay.getBoundingClientRect();
            var x = ((e.clientX - olRect.left) / olRect.width) * 100;
            var yPx = e.clientY - olRect.top;
            var angle = Math.atan2(
                e.clientY - (olRect.top + olRect.height / 2),
                e.clientX - (olRect.left + olRect.width / 2)
            ) * 180 / Math.PI;
            overlay.style.setProperty('--olx', x + '%');
            overlay.style.setProperty('--oly', yPx + 'px');
            overlay.style.setProperty('--ol-angle', angle + 'deg');
            caustic.style.left = (e.clientX - olRect.left - 40) + 'px';
        });
        wrap.addEventListener('mouseleave', function () {
            currentRow = null;
            overlay.classList.remove('active');
        });
    }
    Array.prototype.forEach.call(document.querySelectorAll('.modalBox .tbl'), initTableGlass);

    /* ── glassTrack — 색수차 광원 추적 (--olx/--oly/--ol-angle) ── */
    function glassTrack(el, e) {
        var rect = el.getBoundingClientRect();
        var x = ((e.clientX - rect.left) / rect.width * 100);
        var yPx = e.clientY - rect.top;
        var angle = Math.atan2(
            e.clientY - (rect.top + rect.height / 2),
            e.clientX - (rect.left + rect.width / 2)
        ) * 180 / Math.PI;
        el.style.setProperty('--olx', x + '%');
        el.style.setProperty('--oly', yPx + 'px');
        el.style.setProperty('--ol-angle', angle + 'deg');
    }

    document.addEventListener('mousemove', function (e) {
        var el = e.target.closest('.glass');
        if (!el) return;
        glassTrack(el, e);

        /* 틸트·스케일은 텍스트 블러를 유발해 미사용 — 부상은 CSS(translateY)가 담당 */
    });

    /* ── 클릭 리플 (Materialize waves 풍) ── */
    var rippleFx = document.createElement('div');
    rippleFx.className = 'rippleFx';
    document.body.appendChild(rippleFx);

    document.addEventListener('pointerdown', function (e) {
        if (e.button !== 0) return;
        var r = document.createElement('span');
        var onIntro = ORDER[cur] === 'pgIntro';
        r.className = onIntro ? 'ripple big' : 'ripple';
        if (onIntro) {
            r.style.setProperty('--rsize', '250vmax');
            r.style.setProperty('--rdur', '2s');
        }
        r.style.left = e.clientX + 'px';
        r.style.top = e.clientY + 'px';
        rippleFx.appendChild(r);
        r.addEventListener('animationend', function () { r.remove(); });
    });

    /* ── 테마 토글 (기본 = 화이트, localStorage 유지) ── */
    (function () {
        var btn = document.getElementById('themeToggle');
        var icon = document.getElementById('themeIcon');
        if (!btn) return;
        function applyTheme(light) {
            document.body.classList.toggle('light', light);
            icon.textContent = light ? 'dark_mode' : 'light_mode';
            try { localStorage.setItem('ankTheme', light ? 'light' : 'dark'); } catch (e) {}
        }
        var saved = null;
        try { saved = localStorage.getItem('ankTheme'); } catch (e) {}
        applyTheme(saved !== 'dark');
        btn.addEventListener('click', function () {
            var toLight = !document.body.classList.contains('light');
            if (document.startViewTransition) document.startViewTransition(function () { applyTheme(toLight); });
            else applyTheme(toLight);
        });
    })();

    /* ── 인트로 우주 — 반짝이는 별밭 + 떠다니는 빛 입자 ── */
    (function () {
        var fx = document.getElementById('introFx');
        if (!fx) return;
        /* 별 — 화면 전체, 제자리 트윙클 (일부는 밝은 큰 별)
           delay를 음수로 줘서 위상을 고르게 분산 — 전멸(암흑) 구간 없음 */
        for (var i = 0; i < 216; i++) {
            var st = document.createElement('span');
            var big = Math.random() < 0.16;
            st.className = big ? 'star bigStar' : 'star';
            var ss = big ? 2.5 + Math.random() * 2 : 1 + Math.random() * 1.6;
            var dur = 1.8 + Math.random() * 4.5;
            st.style.width = ss + 'px';
            st.style.height = ss + 'px';
            st.style.left = (Math.random() * 100) + '%';
            st.style.top = (Math.random() * 100) + '%';
            st.style.setProperty('--dur', dur + 's');
            st.style.setProperty('--delay', (-Math.random() * dur * 2) + 's');
            st.style.setProperty('--op', (big ? 0.75 + Math.random() * 0.25 : 0.35 + Math.random() * 0.45).toFixed(2));
            fx.appendChild(st);
        }
        /* 떠다니는 빛 입자 — 아래에서 위로 유영 */
        for (var j = 0; j < 72; j++) {
            var d = document.createElement('span');
            d.className = 'pDot';
            var size = 2 + Math.random() * 5;
            d.style.width = size + 'px';
            d.style.height = size + 'px';
            d.style.left = (Math.random() * 100) + '%';
            d.style.top = (40 + Math.random() * 60) + '%';
            d.style.setProperty('--dur', (10 + Math.random() * 14) + 's');
            d.style.setProperty('--delay', (Math.random() * 14) + 's');
            d.style.setProperty('--op', (0.35 + Math.random() * 0.5).toFixed(2));
            fx.appendChild(d);
        }
    })();

    /* ── 인트로 순환 문구 ── */
    (function () {
        var el = document.getElementById('rollWord');
        if (!el) return;
        var WORDS = [
            '데이터 자산에서 찾는 배합 추천',
            '다음 실험을 알려주는 배합 최적화',
            '시료 없이 미리 재보는 MD 물성 예측',
            '현업과 함께 완성하는 실전 검증'
        ];
        var wi = 0;
        setInterval(function () {
            if (ORDER[cur] !== 'pgIntro') return;
            el.classList.add('out');
            setTimeout(function () {
                wi = (wi + 1) % WORDS.length;
                el.textContent = WORDS[wi];
                el.classList.remove('out');
            }, 460);
        }, 3200);
    })();

    /* init — #pgF3 처럼 해시로 특정 페이지 직접 진입 가능 */
    /* 시작 페이지 (작업 시 'pgF' 등으로 임시 변경 가능) */
    var START_PAGE = 'pgIntro';
    var hashIdx = ORDER.indexOf(location.hash.replace('#', ''));
    show(hashIdx >= 0 ? hashIdx : Math.max(0, ORDER.indexOf(START_PAGE)));
})();
