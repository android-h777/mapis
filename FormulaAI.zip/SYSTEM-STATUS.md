# MD 시스템 현황 + 향후 계획 (세션 간 공유용)

> **최종 갱신 2026-08-05** (최초 작성 2026-06-30). 갱신 이력은 git이 담당 — 파일명에 날짜 안 붙임. **이 md가 원본**, HTML 사본은 공유용 파생물.
> 📖 모르는 용어는 맨 아래 **§11 용어 사전**(MD·화학 전문용어를 IT 개발자 눈높이로 풀이).

---

## 1. 한 줄 요약
PDMS 밀도 검증(MW-matched 대비 **−2.7~−3.7% PASS**, MW 770~2000 4점)으로 시작한 파이프라인이 **물성 9종 레시피 서비스**(밀도·열팽창·CED·HSP·기체용해도·표면장력·Tg·체적탄성률·**기체투과**) + **혼합물(다성분) MD** + **폴리머 입력** + **멀티엔진**(유기 소분자는 GC·QSPR 1초 동기 엔진, Si는 MD 폴백)으로 확장. 서버는 **APIS 연동 비동기 서비스**(FastAPI+Celery+Redis+Oracle) — 앞단 preflight·캐시, 뒷단 검증원장·보정층·신뢰등급·**LLM 리포트(사내망 live)**까지 전부 main 반영.

**지금 위치:**
- ✅ 물성 9종 + 혼합물 + 폴리머 입력 + 멀티엔진(GC·QSPR 동기) = live
- 🚧 진행 중: 기체 **O₂/N₂ Stage2**, **Δ-러닝**(Track B, §7) · KCC 실측 앵커 격상(§8)
- 🔴 판정 종결: **점도 = MD 경로 불가 확정**(§9) / **MLIP 힘장대체 = 종결 NO**(실록산 OOD, §9)

---

## 2. 목표 / 정체성
- **표면 목표**: KCC 실리콘(PDMS) 물성을 MD로 예측. 1차 목표 = 실측 bulk 밀도 **0.965 g/cm³ ±5%**.
  - ⚠ 검증은 **MW-matched 0.918**(Gelest DMS-T05, 모델 10mer 대응 5cSt 실험값) 대비 **−3.7%**로 수행. bulk 0.965(고분자량)와 10mer 값의 직접 비교는 사슬길이(MW) 통제 후에만 공정. ⇒ 2026-08-06 캠페인이 그 통제를 실제로 수행(1250·2000 추가) — §밀도 검증 결과.
- **진짜 목표**: **범용 FF + MLIP MD 플랫폼.** PDMS 밀도는 첫 검증 vehicle — 이후 물성 9종으로 확장하며 **"물성 추가 = 레시피 등록"** 축이 실증됨. 혼합물까지 additive로 확장돼 커버리지가 **"물성 × 소재" 2차원**으로 열림(§3 트랙). 나아가 비-MD 동기 엔진(GC·QSPR)이 붙어 **"엔진" 축**도 열림(§6.5).
- **두 'AI' 축은 다른 층**(혼동 주의): **MLIP**(OrbMol/AIMNet2 등) = **숫자 정확도 축**(물리 엔진 정밀도) ↔ **LLM**(KCC AI) = **설명·판단·오케스트레이션 축**. **LLM 통합은 숫자를 더 정확하게 만들지 않는다** — 신뢰·설명·자동화를 더한다.
- MD는 AI 물성예측을 **보완하는 데이터 엔진**이지 만능 아님. (MD로 안 되는 것 = §9)
- 단계: Phase 3(변종 배치) → Phase 4(APIS 연동 서비스화 — 완료) → (지금) 물성 카탈로그 확장 + 신뢰 인프라 고도화.

---

## 3. 트랙 구성 (역할 분담 — 이 섹션이 트랙 정본)
현재 **4트랙**. **확장 축(A↔D)은 유지**, **혼합물 축(구 B↔C)은 목표 달성·NO-GO 종결로 은퇴** → B·C 재정위(2026-07-20).

**확장 축 — A ↔ D** (커버리지: 무슨 물성 × 어떤 소재까지)
- **A = 물성확장**: 예측 물성 종류 확장, references 큐레이션·property 정의버전·**보정 앵커**. D와 연계.
- **D = 패밀리확장**: 소재 패밀리/변종 확장(APIS 연계·입력파라미터·원료/반제품코드·다중 SMILES→혼합물 조성, DB 소스). A와 연계.

**B = ML 적용** (2026-07-20 재정위): MD를 보완하는 ML 발굴·구축. 사내 관측-지도학습은 라벨 벽에 다 걸림(메모리 `reactive-formulation-label-wall`·`spc-composition-ml-nogo`) → 현재 **Δ-learning**(깨끗한 앵커 라벨로 MD 계통오차 보정, 메모리 `delta-learning-cte-spike`).

**C = 프론트 연동** (2026-07-20 재정위): APIS 프론트엔드 연계·Living Job Page·사용자 대면 통합·배포(메모리 `apis-frontend-notify`·`living-job-page-status`·`triage-ignores-grade-gap`).

**★ 혼합물 축(구 B↔C) 종결 이력** — "포기"가 아니라 두 방향 각각 자연 결론 도달:
- **C 측 = 완료**: 혼합물(다성분) MD 플랫폼 main 371dd2f 머지(§6.4). ⚠ prod `TAP_MD_JOB.SMILES` nullable ALTER는 배포 잔여.
- **B 측 = NO-GO**: 혼합물 ML(서로게이트) 필요성 NO-GO(정본 `ml/surrogate/VERDICT.md` — 공정 경쟁자와 타이·교차화학족 LOFO 실패·능동학습 NO-GO) + Gate-0 리얼리티(PCFF 혼합물밀도가 "실험 순물질+ideal-mixing"에 짐). ⚠ 마스터데이터·인과귀속은 `component-property-data-exists`·`ml-no-go-attribution-limits`가 정정.
- **계약 자산 남음**(components 스키마·canonicalize·B-4 `TAP_MD_RESULT` 레코드)은 재사용 가능.

---

## 4. 아키텍처 한눈에

**범례:** 🟩 구축 완료 · 점선 = best-effort/조건부 경로.

```mermaid
flowchart TB
    Client["🟩 APIS (클라이언트 — 종전 ChemStudio 표기 대체)"]
    FastAPI["🟩 FastAPI · main.py<br/>인증 · preflight 3층 · 물질키 치환 · 캐시 조회 · 큐잉"]
    Library["🟩 구조 라이브러리 app/library/<br/>물질키 → 큐레이션 SMILES+레시피+fidelity"]
    Oracle[("🟩 Oracle<br/>TAP_MD_JOB(잡) · TAP_MD_VALID(검증원장) · TAP_MD_RESULT(B-4 레코드)")]
    Redis[["🟩 Redis 큐 (broker)"]]
    Notify["🟩 통지: 콜백(웹훅) + 이메일"]
    KCCAI["🟩 KCC AI 사내 LLM — 연결 live<br/>/rest/aiRestCall · gemma-4-31b-it · IP인증 · systemId=APIS_MD_REPORT"]

    subgraph Worker["🟩 Celery Worker (비동기 · GPU 1장 · concurrency=1)"]
      direction TB
      MD["🟩 MD 파이프라인 app/md/ — RECIPES 9물성 디스패치<br/>density · thermal_expansion · ced · hsp · gas_solubility(Widom)<br/>surface_tension(slab) · tg(냉각 kink) · bulk_modulus(부피요동) · gas_permeability(P=S×D→Barrer)<br/>+ 혼합물: mixture/census — 이종 타이핑·조성 검증<br/>+ 멀티엔진 engines/ — GC 밀도·QSPR HSP 동기(Si는 MD 폴백)"]
      Grade["🟩 신뢰도 등급 app/report/ = 결정론 규칙<br/>정책 + SEM + 게이트 + references(MW-매칭·exp_unc)<br/>+ (property,family) 그리드 + fidelity·도메인 캡 + trust_verdict"]
      Prose["🟩 report 조립 — LLM 근거서술 + 실패진단 + 능동분석<br/>LLM 실패 시 템플릿 폴백"]
      Record["🟩 B-4 레코드 result_record.py<br/>TAP_MD_RESULT — COMPONENTS/COMP_KEY (Track B 소비)"]
      Ledger["🟩 검증원장·보정 validation.py+calibration.py<br/>(sim,exp) 자동적재 → 오프셋·τ² 불확실도 오버레이(일부 가족셀 활성·나머지 abstain)"]
      MD -->|"값 + run 사실"| Grade --> Prose
      Grade -.->|"참조 있을 때"| Ledger
      Prose -.->|"set_result 후 · fail-open · 멱등"| Record
    end

    Client -->|"POST /jobs (smiles 또는 material)"| FastAPI
    FastAPI -.->|"물질키면 치환"| Library
    FastAPI -->|"202 queued (캐시 히트면 즉시 done)"| Client
    FastAPI --> Oracle
    FastAPI -->|enqueue| Redis --> MD
    Ledger --> Oracle
    Record --> Oracle
    Prose -.->|"HTTP JSON (best-effort)"| KCCAI
    KCCAI -.-> Prose
    Prose --> Notify --> Client
    Client -->|"GET /jobs · /jobs/{id}(+/structure·/thermo·/analysis) · /active · /stats · /library · /validation · POST /validate · POST /jobs/preview(부작용0)"| FastAPI

    classDef done fill:#e8f5e9,stroke:#43a047,color:#1b5e20;
    class Client,FastAPI,Library,Oracle,Redis,Notify,MD,Grade,Prose,Ledger,Record,KCCAI done;
```

**한 줄 독해:** 클라이언트가 SMILES(분자 구조 텍스트 한 줄) **또는 물질키**를 던지면 → FastAPI가 **preflight**(입력·규모·시간 사전검문)와 **캐시**(같은 계산이면 GPU 안 태우고 즉시 반환)를 거쳐 접수(202) → 워커가 GPU로 물성별 레시피 실행 → **결정론 규칙이 신뢰등급을 매긴 뒤** LLM이 근거를 자연어로 풀어 report 조립(사내 LLM live — 죽으면 템플릿 폴백) → 콜백·이메일 통지. 실험 앵커가 있는 잡은 (시뮬값, 실험값) 쌍이 **검증원장에 자동 적재**돼 미래 보정 데이터가 쌓인다. **LLM은 숫자에 손대지 않고**(등급은 코드가 결정) 설명만 하며, 리포트층이 통째로 죽어도 숫자 결과는 그대로 나간다.

---

## 5. 환경 (인프라)
- 서버: `root@infraai` (원격, Ubuntu 24.04). conda env **md_env**(Py3.12, Miniforge).
- GPU: **RTX 6000 Ada ×2** (compute 8.9 = ADA89, 각 48GB). GPU는 **LAMMPS만** 사용.
- LAMMPS: stable(2025-07) 소스 **KOKKOS+CUDA(ADA89) 빌드**. 실행: `lmp -k on g 1 -sf kk -pk kokkos -in in.xxx` (❌ `-sf gpu` 금지). 긴 시뮬은 **tmux 안에서**.
- 힘장: **PCFF**(class2, Si 지원). 도구 LUNAR. (다른 힘장을 왜 안 쓰는지 = §9)
  - ⚠ LUNAR PCFF 타이퍼 버그 패치함(실록산 Si `s_m`→`sio`, `src/atom_typing/typing/PCFF.py`). **IFF 변형엔 버그 남아있음**.

---

## 6. 이미 구축된 것 (DONE)

### 6.1 코어 — MD 파이프라인 + Phase 4 서버 ✅
- **파이프라인 흐름**: `SMILES → RDKit(3D) → Packmol(박스충진) → LUNAR atom_typing(PCFF) → LUNAR all2lmp(+pcff.frc→LAMMPS data) → LAMMPS NPT → 물성별 분석(MDAnalysis 등)`. GPU=LAMMPS만, 나머지=CPU.
- **검증 관문 3개**(에러 없이 조용히 틀리는 지점 — 반드시 숫자로 확인): ① atom_typing 후 unassigned 0개(Si수=사슬수×10 교차확인) ② all2lmp 후 주기 박스 치수 복원 ③ NPT 후 밀도 sanity. + 물성별 수렴·드리프트 게이트.
- **밀도 검증 결과**: **MW 770~2000 4점 전부 PASS**(±5%) — 사슬길이 캠페인 종료(2026-08-06).
  | nominal mw | sim | exp | Δ |
  |---|---|---|---|
  | 770 (10mer) | 0.8843 | 0.918 | **−3.7%** |
  | 770 세대 브리지(현행 코드 재실행) | 0.8853 | 0.918 | −3.6% |
  | 1250 | 0.9091 | 0.935 | **−2.8%** |
  | 2000 | 0.9247 | 0.950 | **−2.7%** |

  ⚠ 구 헤드라인 **−3.5%는 오기**였다 — 구 sim 0.886 세대의 값이 sim 0.8843 갱신 뒤에도
  `delta_pct`에 손입력으로 남아있었다(2026-08-06 정정, 원장 행·회귀가드 포함). PASS는 불변.
  ("8.4% low"는 사슬길이 교란이었음.) 사전등록 §4 판정 = **분기 1 · 상수**(부호 일정,
  range 1.01%p < 2.0, S 0.573% ≤ 2.0, f̄ 1.031). ⚠ 단 |Δ|가 3.7→2.8→2.7로 **줄다가 평탄해지는
  실재 추세**가 있다(range = 10σ̂) — "추세 0"이 아니라 "상수 factor가 쓸 만한 모델"이라는 판단.

  🔴 **자동서빙 미개방 · 허용오차 완화 미배포**(원장 production clean = 2).
  사유 = **§6 4점 관문 미통과** — 3780(nSi 51)이 **packmol 빌드 실패**로 NPT 미도달.
  nloop 400(20배)에서도 실패. 원인은 노력이 아니라 기하 — packmol은 사슬을 강체로만 다루는데
  RDKit 컨포머가 진공에서 뭉쳐(Rg 9.6Å) 서로 관통 못 하는 블롭 12개를 53Å 박스에 넣는 문제가
  된다. **rho0=0.3(박스 63Å)에서는 충진 성공 확인** ⇒ 재개 경로 있음(프로토콜 편차 기록 필요).

  ✅ **이완 아티팩트 우려는 실측으로 해소**(2026-08-07). 초기 컨포머 붕괴가 MW-상관인 건
  사실이나(Rg초기/Rg평형 0.76→0.68→0.65→0.57), 2000을 1ns→5ns로 이어달린 결과
  **Rg는 +13.6%(8.96→10.56Å) 자랐는데 ρ는 −0.0013±0.0010(1.3σ, 미유의)** 로 안 움직였고
  Rg-ρ 상관도 −0.117로 없다. 밀도는 국소 패킹이 지배하고 사슬 펼침(Rg)엔 둔감하다
  ⇒ **분기 1 판정 유효**(보수적 편향 우려 반증). 부수 소득: PDMS **밀도**에 한해 생산
  프로토콜 1ns 충분하다는 실측 근거. ⚠ **밀도에 한해서다** — 점도·확산 등 수송물성은
  Rg 13% 미이완에 그대로 노출된다(수송물성 작업이 이걸 안전신호로 인용 금지).

  상세 = `docs/…/2026-08-06-pdms-density-chain-length-verdict.md`,
  `docs/…/2026-08-07-pdms-2000-relaxation-artifact-test.md`
- **서버 구성**: FastAPI(HTTP 접수) + Celery(워커) + Redis(브로커) + Oracle(영속). 상태머신 `queued→running→done|failed`.
- **코드 레이어**(`server/app/`):
  | 레이어 | 파일 | 역할 |
  |---|---|---|
  | API | `main.py` | 엔드포인트, API키 인증(⚠ 미설정 시 무인증 통과 — §10), preflight·캐시·큐잉 |
  | 워커 | `celery_app.py`,`tasks.py` | `run_property_job` → `recipes` 디스패치 → `report/builder.build` → 원장 훅 |
  | MD | `app/md/*` | build/typing/simulate/analysis/gates/pipeline + `recipes.py`(물성 레지스트리 9종) + `preflight.py` + 물성별 `ced/hsp/widom/slab/tg/kappa/diffusion.py` + `engines/`(비-MD 동기) |
  | 혼합물 | `md/mixture.py`,`md/census.py` | 조성 해석 + 조성 검증 게이트(union-find 분자 재구성) |
  | 입력게이트 | `md/buildgate.py`,`md/molinfo.py`,`md/toolchain.py` | 빌드가능성(Si 다중결합 거부) + 분자 정보 + 툴체인 패치상태 스탬프 |
  | 캐시 | `cache.py` | canonical SMILES+params+버전지문 exact-일치, fail-closed + stampede 가드 |
  | 라이브러리 | `library/loader.py`+`catalog.json` | 물질키→큐레이션 SMILES·레시피·fidelity (부팅 fail-loud) |
  | 입력해소 | `resolve.py`,`opdb.py` | Track D direct/by-code 입력계층 + 운영DB READ-ONLY 조회 |
  | 신뢰/리포트 | `report/{builder,confidence,grade_grid,triage,provenance,references,diagnosis,analysis}.py` | provenance → 결정론 등급(+가족 그리드) → trust_verdict → report 조립 + 실패진단 + 능동분석 |
  | LLM | `llm/client.py` | KCC AI 호출 래퍼 (실패 시 None → 템플릿 폴백) |
  | 원장/보정 | `validation.py`,`calibration.py` | (sim,exp) 자동적재 + 오프셋·τ² 보정 오버레이 |
  | B-4 레코드 | `result_record.py` | `TAP_MD_RESULT` write 훅 — 전용세션·fail-open·멱등 |
  | 영속/통지/진행률 | `jobs.py`,`db.py`,`notify.py`,`progress.py` | Oracle thick CRUD + 콜백/이메일 + 단계·ETA |
- **모니터링 API**: `GET /jobs`(필터/페이지)·`/jobs/active`·`/jobs/stats`·`/jobs/{id}`·`/library`·`/validation`(검증 성적표). `/docs` Swagger가 최신 레퍼런스.
- `params.profile`: `smoke`(빠른검증) / `production`(평형밀도).

### 6.2 물성 레시피 9종 ✅
> 신뢰도 정책 정본 = `report/confidence.py` `RELIABILITY_CLASS`. **절대값** 신뢰 = 밀도·열팽창 / **양호** = CED·HSP·기체용해도 / **트렌드만** = 표면장력·Tg·체적탄성률·**기체투과**(+확산).
> ⚠ **이건 2축 중 "물성 축"(=신뢰 천장)일 뿐 — 실제 신뢰 = f(물성, 셀검증)이다.** 아래 표 등급은 **검증된 단일성분 셀**(예: PDMS) 기준이고, **미검증 셀**(혼합물·미벤치마크 종 siloxane_other 등)은 `grade_grid.cap_class(property, species)`가 **트렌드/low로 강등**한다(천장은 못 올림). 예: 같은 **밀도**라도 **PDMS=절대값 / 혼합물=트렌드**(혼합물은 조성 축이 없어 검증 레퍼런스·calibration 둘 다 abstain — §8 mixture 앵커, 메모리 `openapi-frontend-contract`). 물성 단독으로 신뢰를 읽지 말 것.

| 물성 | 방법 | 등급 | 핵심 결과 · 주의 |
|---|---|---|---|
| **밀도** | NPT 평형 | 절대값 | MW 770~2000 4점 **전부 PASS**(Δ −3.7 / −2.8 / −2.7%). 사전등록 판정 = 분기 1·상수(f̄ 1.031). ⚠ 구 헤드라인 −3.5%는 오기 · 🔴 자동서빙 미개방(3780 빌드실패 — rho0=0.3 재개경로 있음) · ✅ 이완 아티팩트 우려는 5ns 실측으로 반증(Rg +13.6%인데 ρ 미유의 1.3σ) — § 위 표 |
| **열팽창(CTE)** | 5온도 ρ(T) 선형피팅 → α_V | 절대값 | α_V 9.13e-4, low(과소예측). ⚠ 정의불일치 보정 시 **공정 Δ ≈ −15~16%**(판정 생존). PCFF 분산 과소결합 계통 패턴(HSP δD와 동근) |
| **CED** | 응축−기체 에너지차 → 응집에너지밀도 | 양호 | 기체상 강제 + 기체 수렴 게이트 |
| **HSP** | CED를 δD/δP/δH 분해 | 양호 | δ **11.94**. ⚠ 잔차는 **성분별**(δD 과소 −26.5% + δP 과대의 우연 상쇄 — 단일%로 뭉치지 말 것). etail은 evdwl에 **이미 포함**(이중계산 금지) |
| **기체용해도** | 오프라인 **Widom 입자삽입** | 양호(trend 앵커) | He/Ar Stage1 착지(He μ_ex +1.047). O₂/N₂ Stage2 진행 중(§7). 무전하 1-site LJ |
| **표면장력** | 슬랩 압력텐서 이방성 → γ | 트렌드 | γ **18.9 mN/m**, 앵커 Gelest 19.7 근-실험. ⚠ ⟨Pzz⟩는 평형신호 아님(드리프트-전용 게이트)·슬랩엔 bulk 테일보정 무효 |
| **Tg** | 냉각 램프 → ρ(T) kink | 트렌드 | RAW 배출(오프셋 **~+35K**는 보정층 소관, +80K 아님). 냉각속도 ~12 decade 빨라 절대값 계통 높음. 앵커 exp 140±6 검증 대기 |
| **체적탄성률** | NPT 부피요동 → κ_T → K=1/κ_T | 트렌드 | K 0.73 GPa. ⚠ **앵커 정정(2026-07-21): 구 1.0 GPa 반증**(K_T<K_S 위반)→ **0.74**, `|Δ|≲13%`. 종전 "−27% 과압축성" **철회** |
| **기체투과** | Widom S × MSD-아인슈타인 D → Barrer | 트렌드 | P=S×D(2026-07-30 등록·9번째). Ar e2e ~3,700 Barrer(막앵커 ~630의 ~6배 — 미가교 melt 자유부피, 방향 정합). rel-SEM~18%(곱). v1=Ar만 |

- 공통: `value=None` 배출 가능(통계 미달 시 값 대신 None + confidence 가드). per-recipe `param_defaults` 오버레이로 공유 상수 지뢰 회피.

### 6.3 신뢰·보정 인프라 ✅
- **preflight 3층**(`md/preflight.py`, dd40394): A=입력검증 / B=규모(원자 절대상한) / C=시간(벽시계 추정·doomed 가드, 실측 THROUGHPUT 보정). 접수 시 400 빠른 실패 + `estimated_seconds` 노출. "MACE ~250 GPU-h 실측 없이 태울 뻔한" 교훈의 박제. ⚠ 힘장·엔진·GPU 변경 시 `THROUGHPUT`·`MAX_TOTAL_ATOMS` 재보정.
- **캐싱**(`cache.py`, 7afb739): canonical SMILES + 선언 params + 코드/env 버전지문 → exact-일치. fail-closed. 캐시 히트 시 보정 오버레이는 strip 후 재적용 + in-flight stampede 가드.
- **검증 원장**(`validation.py`, `TAP_MD_VALID`, 972be76): 실험 앵커 있는 잡마다 (sim, exp, Δ%, 게이트, 등급, MW, FF, 정의버전, exp_uncertainty…) 자동 적재(전용 세션 — 메인 잡 세션 오염 금지). ⚠ **CED는 원장 제외**(비휘발성 PDMS는 exp CED=δ²라 독립정보 0 = 과적합 연료 — 백필은 density/CTE 2점만, **다시 넣지 말 것**).
- **보정층**(`calibration.py`): 물성×FF×profile×정의버전 그룹키로 오프셋 factor 학습 → **raw 불변 오버레이** 보정. 초과분산 τ²를 불확실도로 전파. N<3·species-None은 **abstain**(정직). **(물성×가족) 셀 단위 — 깨끗한 앵커 3점+ 셀부터 발동**. 실서빙 현황(2026-08-03): **epoxysilane**(factor 1.0420)·**aminosilane**(1.0588) 발동 / **alkoxysilane** 발동 가능(0.9908) / **acetoxysilane·silazane**은 `anchor_trust` 활성화 후 clean 1~2점으로 내려가 `insufficient_data` abstain / cyclic은 동종 가족이라 MW-nearest가 앵커를 잡아 보정 경로 미도달(설계대로). ⚠ 통계 상수는 정규직관 금지, **시뮬 FP가 판정**(LOO가 소표본서 3번 배신한 교훈). ⚠ `family_class` 셀 caveat는 보정 제공을 **단정하지 않는다**(결정론 층은 원장 연료를 못 봄 — 적용 여부의 단일 진실원은 `detail.calibration`).
- **(property,family) 그리드**(`report/grade_grid.py`, 78b131c): 물성×화학가족 셀 + 불변식. **density 셀 7개**(2026-08-03 현재) — PDMS·cyclic·alkoxysilane = absolute / acetoxysilane·silazane·epoxysilane·**aminosilane**(신설 `bedc673`) = `family_class="trend"`(계통 바이어스 검증 = 순위 신뢰·절대값 X). 비-density는 PDMS만(hsp·CTE·γ·Tg). ⚠ 미해결 = 가족 입도/대표성.
  - **근거 원장화 완료**(사전등록 `docs/…2026-07-16-track-d-cell-evidence-preregistration.md`): 셀 근거가 주석·scratchpad에만 있던 상태를 **정식 잡 경로 재실행**으로 해소. cyclic(D4 −3.4/D5 −2.9/D6 −2.5%)은 **firm 앵커만으로 연료되는 유일 셀**(provisional_n=0). 판정 기준은 **실행 전 사전 등록**(결과 보고 기준 고르는 사후합리화 차단).
  - **vinyl_siloxane = 가족 분리 O, 셀 미개방**(`cd3e20b`): 운영DB 최대 미커버 가족(제품 497/525)에서 비닐 축 분리. 좁은 정의(메틸·비닐만 — 미검증 화학의 등급 상속 차단). 앵커 5점 중 clean 2(<K_MIN 3) → **셀 없음**이 최종. 죽은 후보 4종(CAS·사유)까지 §12.11에 기록 = **재탐색 금지**.
  - **앵커 SMILES canonical 매칭**(`6bd7572`): 이종 가족 매칭이 raw 문자열 비교라 비-canonical로 등록된 앵커가 **에러 없이 영구 미매칭**(원장 0행)될 수 있었다. 소비 지점에서 정규화 + 불변식 테스트 → 큐레이터 표기형식 무관.
- **trust_verdict**(`report/triage.py`, 802c328): 사용자향 **결정론** 신뢰 판정 + prominent 선두 리드. trend_only union(grade OR reliability). **LLM 아님 — 코드가 정함.**
- **LLM 리포트**(사내망 **live**, `KCCAI_ENABLED=true`): 신뢰등급은 결정론 코드, LLM은 근거를 자연어 서술만(감사·재현 가능). 빌드 순서(리스크 기준) ① 리포트+신뢰도 ✅ → ② 실패진단 ✅(오진 방지 포함) → ③ 능동분석 ✅(`report/analysis.py`, done=4관점·running=3관점, `GET /jobs/{id}/analysis`; 대화형 Q&A는 폐기) → ④ 레시피 결정(다음 후보, LLM이 물리 숫자에 영향=최고위험) → ⑤ MCP/변종루프.
  - **KCC AI 계약**: `POST https://kccai.kccworld.co.kr/rest/aiRestCall`(비스트리밍), 인증=IP 화이트리스트, 모델 = **gemma-4-31b-it**(사내 호스팅; 종전 "gpt-4o" 표기는 오류였음). 네이티브 구조화출력 없음 → 프롬프트+파싱+검증.
  - degraded: LLM 실패 시 confidence 그대로 + report 템플릿 폴백, job 안 죽임.

### 6.4 입력·확장 ✅
- **SP-A 구조 라이브러리**(431577a): `POST /jobs`가 생 SMILES 외 **물질키**(`{"material":"…"}`) 수용. 치환 시 구조결정 파라미터(n_chains/rho0)는 **서버 권위**. **fidelity 3단**(exact/representative/coarse)이 confidence 캡에 연결. ⚠ 카탈로그 rho0=0.5(과밀 0.9가 packmol STOP 173 원인).
- **혼합물(다성분) MD 플랫폼**(main 371dd2f): 계약 가드레일 먼저(ebd7c09) → **additive 확장**(단일성분 경로 불변). `md/mixture.py`(조성 해석)·`md/census.py`(조성 검증 — union-find). e2e 검증(밀도 0.7845 + B-4 레코드). ⚠ **prod `TAP_MD_JOB.SMILES` nullable ALTER 선행 필요.** 🔴 혼합물 **밀도**는 값어치 낮음 = §9.
- **폴리머 입력 전개**(main 8f6b26c, 2026-07-23): 사용자가 그린 **순수 선형 호모폴리머**(반복단위 PSMILES + 목표 Mn)를 `POST /jobs {polymer}`로 접수 → 서버가 접수 시점에 명시적 올리고머 SMILES로 전개(`md/polymer.py`, 순수 RDKit) → 기존 파이프라인 재사용. v1.1 스코프 = **순수 선형 호모폴리머만**(공중합/statistical/side_chain은 스키마 동결 + `UNSUPPORTED_*` 게이트). 🔴 **오귀속 4중 게이트**: 비-PDMS 폴리머는 순물질 셀·보정팩터 상속 안 함(등급 클램프·calibration no-op·no_cache·grade_ceiling low) — **PDMS 폴리머만** 검증 셀 신뢰 상속. 신규 59 테스트.
- **Track D 입력해소**(`resolve.py`, 9439e59/6ebb4ff): direct 입력계층 + **빌드가능성 게이트**. by-code(material_code)는 **운영DB READ-ONLY**(952b187). 빌드게이트 하드닝: Si 다중결합 거부(실리카·가짜 실라논 차단) + 게이트 2.5(all2lmp 미파라미터 제로계수 조용한 붕괴 차단).
- **by-code 대리구조 가드**(`resolve.py`, `10723ef`, spec `docs/…2026-07-30-bycode-surrogate-structure-guard-design.md`): 운영DB가 **폴리머·등급물질을 소분자 SMILES로 등록**한다(예 CAS 68083-19-2 "Silicone Vinyl Polymer" → mw 186 디실록산, 참조 제품 477건). 그대로 돌면 제품(ρ≈0.97)이 아닌 **다른 물질의 물성**(0.81 레짐)이 나오고, 이건 힘장·앵커·셀로는 못 고치는 **입력 충실도** 문제다. 신호 = 회사 자체 라벨(`RATE_DTL.DESCR` 폴리머 마커, **CAS 단위 집계** — 행단위는 대표사례 93%를 놓침). 조치 = 새 터미널 상태 **`SURROGATE_STRUCTURE` 400 거부**(강등 아님 — 값 품질이 아니라 물질 동일성 문제라 불확실도로 정직해질 수 없음; `library/loader.py`가 큐레이션된 대리구조에만 justification+fidelity를 허용하는 선례와 정합). 오탐 해제는 **(CAS, canonical SMILES) 쌍** 허용목록(Track A 소유, 현재 0건). 같은 커밋에서 **플레이스홀더 CAS**(`0000000-00-0` → 성분행 2,621건이 임의 구조 하나로 해소되던 경로)도 형식검사로 차단. ⚠ 한계 명시 = DESCR 무라벨이 성분행 70.5%·CAS 50.8%라 **절반은 원리적 판정불가**(순수 신규 보호는 27 CAS).
- **원료코드 다성분 실행**(`resolve.prepare_bycode_composition`+`planning.py`, `667fc3e`·`51ab651`,
  spec `docs/…2026-08-06-bycode-multicomponent-execution-preregistration.md` · ✅**배포·LIVE 2026-08-07 00:53 UTC**):
  다성분 원료코드가 `MIXTURE_UNSUPPORTED` 400 → **202 실행**(**355건** = 혼합물 266·드롭단일 82·병합단일 7 ·
  전체 대비 **+4.6%p** · 구조적 천장 16.5% 대비 실현율 10.0%→**14.6%**).
  ⚠ **목표는 정확도가 아니라 커버리지**다 — §9의 "혼합물 밀도 = 값어치 낮음" 판정은 그대로이고 결과는
  trend/low 등급 + caveat로 나간다. "혼합물 밀도가 이제 된다"는 뜻이 **아니다**.
  - 전처리 = **canonical 병합 → Σ=100 정규화 → 몰-공간 드롭**. 병합은 '가짜 다성분'(동일 CAS 다중 행,
    Σ=200/300)을 정상 순물질로 되돌린다(7건). 드롭 질량 합 >5wt%면 `TRACE_MASS_EXCEEDED` 거부.
  - 🔴 **드롭은 wt%가 아니라 몰 공간에서, 그리고 반복 수렴으로** 판정한다. count-0는 largest-remainder
    배분에서 생기므로 wt 임계는 단위 착오이고(v1 오류), 성분을 빼면 잔여분이 줄어 **경계 성분이 다시 0**이
    되므로 단일 패스로는 못 잡는다. 두 결함 모두 **전수 예측표 대조가 잡았다**(각 5건).
  - 🔴 **순서 불변식**: 대리구조 가드(위 항목)는 `resolve_material_code` **내부**, 드롭은 그 이후 →
    역전이 코드 구조상 불가능. 역전 시 트레이스 대리구조 41건이 조용히 통과한다.
  - **드롭 메타는 요청자 params + 캐시 히트 오버레이**: 조성이 같은 서로 다른 원료코드가 캐시 키를
    공유하므로(코드 50건이 키 21개) result 본문에 실으면 **남의 드롭 목록이 서빙**된다.
  - **수용 게이트**: 구현 **전에** 전수 예측표(4,910건)를 고정하고 착지 후 대조 — **일치율 100%**.
    무작위 표본 기준을 폐기한 이유 = 통과율 27.9%에서 "무작위 20건 전부 통과"는 확률 ~1e-11로
    실행 불가능한 기준이었고, 그러면 착지 시 '후보 재정의'라는 도피처가 열린다.
- **B-4 결과 레코드**(`result_record.py`, spec 8588a5d): **Track B가 소비하는 MD 결과 시임**. COMPONENTS/COMP_KEY·`build_row`·전용세션·fail-open·멱등. dev Oracle 실백필 18행.
- **`POST /jobs/preview` — 제출 前 부작용0 미리보기**(main `aa38514`, 2026-08-06 · spec `docs/superpowers/specs/2026-08-06-jobs-preview-api-design.md` · ✅**배포·LIVE 2026-08-06 08:02 UTC**): 이 요청이 **실제로** 어느 엔진·얼마나 걸리고·캐시 히트인지·신뢰등급 천장·수락 가능한지를 제출 전에 보여준다(잡 INSERT·캐시/원장 쓰기·GPU **전무**, in-transaction write-spy로 강제).
  - 🔴 **충실성의 근거 = `plan()` 추출**(Phase A, `planning.py`): `/jobs` 정문을 **순수 결정함수 `plan()` + 실행**으로 쪼개고 preview는 **같은 `plan()`** 을 소비한다. 별도 재구현이면 반드시 드리프트하고, 드리프트한 preview는 없느니만 못하다(동기 시나리오 자체를 오도). §13 골든 동등성 테스트가 `plan()` outcome ≡ `submit_job` 실제 분기를 고정.
  - 응답 = `submittable`(수락 예측) + `engine`/`engine_reason`(실제 라우팅) + `fast_path`(더 빠른 경로 **자문**) + `cached` 삼상태 + ETA **3분리**(`compute_seconds`/`queue_wait_seconds`/`eta_seconds` + `eta_basis` enum) + `grade_ceiling` + `resolved`. **거부도 200**(정보), 예외는 503(운영DB 장애)·422(스키마·길이캡)뿐.
  - **`/validate`와는 (b) 공존**(대체 아님): preview=**수락** 예측기(정적 buildgate)·validate=**빌드성공** 예측기(실제 dry-run). `submittable:true` + `unbuildable` **공존 가능**(예: 트리메틸실란올). 제출버튼 = `submittable==true` AND 최신 `validate.verdict != unbuildable`.
  - ⚠ **기존 `/jobs` 행위 델타(APIS 프론트 통지 완료)**: by-code 해소가 **45s in-process TTL 메모**를 `/jobs`와 **공유**한다 → 배합/조성 변경이 최대 45s 늦게 제출에 반영(워커·uvicorn 재기동 = 즉시 퍼지). 공유가 옳은 이유 = 분리하면 preview↔/jobs 해소가 갈려 골든 동등성이 깨짐.
  - ⚠ **계약 델타**: `MIXTURE_UNSUPPORTED` **생산자 소멸**(다성분 원료코드 400→202 전환) · `TRACE_MASS_EXCEEDED` 신설 · `resolved.source`가 by-code 다성분에서 `"internal"` → 프론트는 **`components` 키 유무**로 혼합물을 판정할 것(`source` 문자열 금지).
  - **OpenAPI(`/openapi.json`)가 프론트 셀프서브 계약의 정본** — 응답필드·status enum·422 경계·디바운스(raw 300ms)·프록시 타임아웃 ≥5s가 전부 description에 있음.
  - **라이브 실측**(배포 직후 + 16h 후 재확인): `/health`·외부 `70.11.11.234:8000`·`/openapi.json` 전부 200(paths 12) · `engine_reason` 4분기 전부 의도대로(생략→`기본 MD 파이프` · auto+유기→`자동 라우팅 — GC 엔진 적격` · auto+실리콘→router 사유 · 거부→null) · **부작용0 실측**(preview 5회 전후 잡 수 50→50) · `/jobs` 정문 계약 불변(미지원 물성 = bare string detail).
  - ⚠ **프론트 feature-detect 함정**: 배포 前 `POST /jobs/preview`는 **404가 아니라 405**였다(`GET /jobs/{job_id}`가 `"preview"`를 job_id로 매칭). 엔드포인트 가용성 감지에 404만 보면 안 된다.

### 6.5 멀티엔진 — 비-MD 동기 엔진 ✅
- **엔진 축 신설**(`app/engines/`): 물성 계산이 MD 전용이 아님. 유기 소분자는 **1초짜리 결정론 동기 엔진**으로 답 — GPU·파일 미사용, 즉시-done 잡(202-균일·캐시히트 선례).
  - **GC 밀도**(`gc_density.py`): 그룹기여(Joback 임계물성) → Rackett 상태식 → ρ@298.15K. **사내 검증셋 200종**(§6.6)으로 실측 — 도메인 안 |Δ| **중앙값 3.2%·≤10% 82%·계통편향 +1.9%**(출처명시∧온도정합 n=49).
    - 🔴 **도메인가드 = `중원자 ≤ 18` ∧ `회전가능결합 ≤ 6`**(38b1047). 실패축은 크기가 아니라 **사슬 유연성** — Joback이 긴 유연사슬 Tc를 과대추정 → ρ 계통 과대. 문헌 사다리로 확인한 연속 악화: 도데칸 +6.2% → 트리데칸 +10.1% → 테트라데칸 +14.3% → 펜타데칸 +18.5%. 반면 같은 크기라도 강직 분자는 양호(벤질벤조에이트 +6.3%·DMP +5.6%)라 크기 단독컷은 이들을 잃는다.
    - ⚠ 구 캡 30은 프로토타입 13종에서 외삽한 값이었고 **DINP(가소제·상용원료) 실제 0.974에 1.906(+95.7%)을 서빙**했다. ✅ **`38b1047` 배포됨**(2026-08-07 00:53 재배포에 포함) — 라이브가 캡 15 중간상태로 서빙하던 갭 해소.
  - **QSPR HSP**(`qspr_hsp.py`): RDKit 17서술자 → GBR 3모델 → δD/δP/δH@298.15K. Butina GroupKFold MAE δD 0.61·δP 2.02·δH 1.61. ⚠ 모델 불확도는 stats.sem 금지(별도 필드)·R² 미서빙(분할 요동).
- **라우팅**(`router.py`, `engine="auto"`): (물성,구조)→엔진 선택, 판정은 각 엔진 `can_handle`에 위임(술어 중복 금지·Fable 2R). **Si는 학습분포 밖 → MD 폴백**. engine 생략=MD 불변.
- **정직성**: `engine_kind`(MD·GC·QSPR·DB) provenance 스탬프 + 비-MD 엔진은 **trend 고정 + "사내 앵커 미확보" caveat**(MD 도메인 셀 게이트 우회). ⚠ provenance가 engine_kind로 분기 — 비-MD엔 MD 기본값(PCFF/LAMMPS/LUNAR) 미부착(감사 오염 차단).

### 6.6 유기 밀도 사내 검증셋 ✅ (2026-08-05)
GC/QSPR 엔진을 배포하고도 **사내 검증 근거가 0**이던 갭을 메운 자산. 운영DB `TAP_PL_VALUE`(C1/R1/S1) → `TAP_PL_CHEM`(CAS 마스터)에서 유기 밀도를 수확.
- **자산**: `server/tests/data/organic_density_valset.json`(200종) + 빌더 `scripts/db/build_organic_valset.py` + 회귀 `server/tests/test_gc_density_valset.py`.
- **수확 경로**: CAS 물질 2,436 → 밀도+온도 517 → SMILES 366 → 유기·중성·단일 302 → **액체상태 204** → 타당대역 201 → 내부정합 **200**.
- 🔴 **방법론**: 문헌값과 어긋난다는 이유로는 **거르지 않는다**(엔진 정확도 부풀림 방지). 필터는 엔진과 무관한 것만 — 상태(고체=결정밀도)·타당대역·내부 불일치·폴리머 CAS.
- 🔴 **판정은 `attributed ∧ 온도정합(20~30℃)` 부분집합에서만**(n=49). `source_text` 없는 130종은 **할로겐 화합물 밀도를 죄다 0.7~0.9대로 적어놓은 계통 오류**가 실재(브로모아세트산 0.89, 실제 1.93) → 그 오차는 데이터 탓이라 회귀 신호가 못 된다. 엔진은 298.15K 계산이라 15℃·75℃ 값과 비교하면 하네스가 편향(온도 불일치만 |Δ| 20.0% vs 정합 3.2%).
- **한계**: 이 셋은 **유기 전용**이다. 규소 함유 후보는 13행뿐이고 정밀도 2~3자리·SG 기준온도 미상·명백한 오류 포함(TMS 1.0, 실제 0.648) → **실록산 MD 앵커는 Gelest 유지**가 맞다(§8-2).

---

### 6.7 커버리지 실측 — "KCC 소재를 어디까지 답하는가" 📊
**2026-08-06 Track D 전수 측정**(대표 원료코드 7,652건, 정본 `docs/…2026-08-06-operational-db-coverage-map.md`):
VALIDATED(셀 검증·등급 부여) **0.7%** · UNVALIDATED(빌드 O·셀 X → low) 7.7% · MIXTURE(by-code 다성분 거부) 12.1% ·
SURROGATE(가드 차단) 8.2% · UNBUILDABLE(염·수화물·금속 = 정직한 경계) 6.8% · **구조 데이터 부재 64.5%**
(PARTIAL 30.2% + CAS 플레이스홀더 22.1% + NO_STRUCTURE 12.2%).

🔴 **함의 — 커버리지 병목은 힘장·앵커·셀이 아니라 운영DB 데이터 품질이다.** 특히 `0000000-00-0`
플레이스홀더 **한 값**이 원료코드 2,169건을 막는다(성분 CAS 미등록 = 우리 코드 밖, 업무 회부 사안).
셀 축이 좌우하는 범위는 8.4%뿐이고 그중 실록산계는 0.2% ⟹ **앵커·셀 작업은 정확도 축이지 커버리지
축이 아니다**(두 축을 섞어 우선순위 매기지 말 것).
🔴 **정정(2026-08-06)**: "다음 최대 단일 레버 = 원료코드 다성분 배선(12.1%)"은 **틀렸다**. MIXTURE 버킷은
선행 사유 계상(buildgate 이전)이라, 실제 배선 효과는 **357건 = +4.7%p**다(나머지는 대리구조 355 ·
**무기 성분 보유 565** — 알루미늄·실리카·철·TiO₂ 등 충전 배합이라 buildgate가 코드 전체를 거부).
원인 = "구조 보유 = 실행 가능" 등치 오류(buildgate는 성분이 아니라 **코드**를 거부한다).

✅ **실현율 갱신(2026-08-07)**: 원료코드 다성분 배선이 배포되며 답을 받는 코드가 **+355건** 늘어
천장 16.5% 대비 실현율이 **10.0% → 14.6%**가 됐다(§6.4). 남은 미실현분(약 1.9%p)은 대리구조 거부·
무기 성분·드롭질량 초과라 **정당한 거부**다 — 즉 이 축에서 더 짜낼 것은 사실상 없다.

🔴 **구조적 천장 = 16.5%**(2026-08-06 실측): 배선·앵커·셀과 무관하게 결정되는 분류 —
**성분 정체 불명 64.4%**(영업비밀·미등록, 공급사가 안 주면 영구 불가) · **무기·금속 성분 포함 19.1%**
(충전 배합 = MD 대상 아님) · MD 가능 단일 10.0%(이미 서빙) · MD 가능 다성분 6.6%(배선하면 열림).
⟹ **한계는 플랫폼이 아니라 소재 자체**다. 커버리지 목표를 세운다면 분모는 7,652가 아니라 **1,264**.
(메모리 `md-fit-landscape`의 "MD in-domain ≈5~10%"와 정합.)
⚠ **한계**: MD density 셀 경로만 판정 — `engine="auto"` GC 엔진이 비-실록산 유기 573건을 trend로 답하므로
**실제 응답률은 0.7%보다 높다**(GC/QSPR 수정 중이라 미측정, 정리 후 재측정).

---

## 7. 진행 중 · 미착지 🚧
- **기체 O₂/N₂ Stage2**(Track A): 스펙+플랜 c32a3d7, **Phase1 착지**(d6e3ef7 — 12-6 LJ 교차 커널 + group/group 게이트 + 막앵커 방향게이트). O₂/N₂ = 무전하 1-site LJ(TraPPE는 전하 있어 배제). 진행 중.
- **Δ-러닝**(Track B): MD 계통 잔차를 깨끗한 앵커로 사후 보정(상수→서술자 함수 확장). CTE·amino 밀도 신호 스파이크 착지·판정 provisional(앵커 소수 상한). 메모리 `delta-learning-cte-spike`·`delta-learning-amino-density-signal`. (※ 투과도·멀티엔진은 착지 → §6.2·§6.5.)
- **설계만(미구현)**: NPT 적응형 조기종료 slice2(60c1866) · structure-endpoint(2026-07-15, spec만).

---

## 8. 향후 로드맵 (우선순위)
1. **(🚧 Track A)** 기체 O₂/N₂ Stage2 → 확산 D · 투과도 P=S·D 환산(§7).
2. **(대기 — Track A)** **KCC 실측 앵커 격상** — 🔴 **기대치 대폭 하향(2026-08-05 실조사)**. `TAP_SP_QC_DTL` 사내 측정 밀도/비중 158행을 전수 분류한 결과:
   - **독립측정은 45%뿐**(48/106): COA 복사 24% · 규격 경계값 13% · **규격 중앙값 16%**(= 규격창이 카탈로그값 중심이라 **우리 앵커와 순환**. VTMS가 실례 — 규격 0.958~0.978의 정중앙 0.968 = **당시** 앵커값). ✅**2026-08-06 VTMS는 순환 해소**: 앵커가 1차 실측 **0.9657**(JCT 2017, 진동관, NIST ThermoML)로 정정돼 규격 중앙값 0.968과 분리됨 — 순환 진단 자체는 유효하나 이 실례는 더 이상 순환이 아님.
   - 살아남는 실리콘계는 **4종**(디비닐테트라메틸디실록산·MPTMS·AEAPTMS·APTMS). 그나마 **온도 미표기**(AEAPTMS)거나 **양(量) 미판별**(비중/밀도 겸용 ASTM D1298·`UNIT=None`)이라 앵커 요건 미달.
   - ⇒ **"문헌(Gelest)→KCC 실측 승격"은 현 데이터로 불가.** 진짜 병목은 행수가 아니라 **온도·양(量) 규약 표기 결손**이고, 해소 경로는 **사내 시험방법 문서의 규약 확정** 하나뿐(아미노실란 건 Track A 판정: "SG로 기움"이 아니라 **미결(동급)**).
   - 부수 소득: 미커버 셀 신규 앵커 후보(티올 MPTMS·페닐·옥심) 식별 — 단 같은 표기 결손에 걸림.
   - 잔여 항목: **gas_solubility 유체 앵커 큐레이션**(🔴 등급 승격의 유일한 연료 — §8-6) / Tg(exp 140±6)·bulk_modulus(mw770) 앵커 검증.
   - **vinyl_siloxane = 공개 데이터 고갈(2026-08-03 종결)**: 5종 조사 = 벤더 1차값 2(clean) / aggregator-only 3 / 값 전무 1 ⟹ clean 3점 미달로 셀 미개방. **적극 재탐색 안 함**(죽은 후보 CAS·사유 = 사전등록 §12.11). 재개 트리거 = clean 1점 확보 시 잡 1건(~15분)+§12.5 결정트리 → 제품 251건 `unvalidated`→`trend` 승격. 남은 현실 경로 = KCC 사내 **통제 실측**(비중 아닌 25 °C 밀도).
3. **(대기 — Track C)** prod `TAP_MD_JOB.SMILES` nullable ALTER(혼합물 전제) / 소프트런치 OPS 갭: **API 무인증**(가오픈 전 API_KEY + APIS 조율 필수)·SMTP 플레이스홀더 / deferred: reaper·rate limit.
4. **(대기 — Track B)** 혼합물 ML. ⚠ 선결 = 룸채널 데이터셋 정본 재구성(`TYPE_ID` 뭉치기 + `MEAS_USE='Y'` 미적용 교정, 메모리 `sapis-schema-source-ref`) + 조성 질량소실 버그 수정. 재구성 후 NO-GO 유지 여부 미확정.
5. **Phase 3 GPU 병렬**: 워커별 GPU 핀 **미구현**(§10). 이후 LLM 레시피 결정(shadow), MCP 게이트웨이/변종 설계 루프.
6. **(대기 — Track A)** **등급 승격 경로** — 2026-08-05 전 셀 스냅샷 결과 **지금 올릴 수 있는 셀은 없다**. 원인이 둘로 갈리니 섞지 말 것:
   - ❌ **MD 계통 바이어스가 원인**인 캡(acetoxy·silazane·epoxy·amino density의 `family_class="trend"`) → **앵커로는 안 풀린다.** PCFF 자체 오차(아민 H결합 응집 과소평가 −4~6% / 에스터O·Si-N 파라미터 +4~6% 과밀)라 앵커를 firm으로 올려도 캡이 유지된다. **앵커 trust는 등급이 아니라 보정(calibration) 적격성만 정한다** — 이 둘을 혼동하지 말 것.
   - ✅ **앵커 부재가 원인**인 캡 → 앵커만 생기면 올라간다. 설계상 승격이 **예약**된 자리:
     · `gas_solubility:He/O2/N2`(정책 **good**인데 셀 미시드로 trend) — `lookup`이 3종 모두 **None** 반환. O2/N2의 유일한 앵커는 `anchor_type=membrane_bound`(Park 2019 **가교** 엘라스토머·308K·겔분율 78%)라 `lookup`이 명시 제외 → **유체앵커 0점**. 필요한 것 = **비가교 PDMS 유체**의 Ostwald 계수 L @298K. 확보 시 `_CEILING["good"]` = **medium** 승격.
     · `bulk_modulus` — 앵커 1점(유도값). trend→good은 정책 변경 + K_T 2번째 독립 앵커 필요.
   - ⚠ **부수 발견(회부 완료 `e7370fd`)**: `references.lookup`이 `anchor_trust` 누락 시 기본값 **"firm"**(fail-open). 비-막앵커 42점 중 15점 미명시이고 그중 **2점**(`tg` 140.0 · `bulk_modulus` 0.74)은 자기 source 텍스트가 스스로 provisional이라 적어놓고 firm으로 서빙 중. 실피해 0(둘 다 원장 0행)이나 다음 런이 firm으로 적재되면 `_eligible` 통과 + `u_sys` 0 전파. **기본값을 뒤집는 건 오답**(나머지 13점은 Gelest/Hansen 직접값이라 오강등) → 고칠 자리는 `references.json`의 그 2점.

**신규 물성 지시(2026-07-07 경영: 유연성·점탄성 / 계면활성·가교 / 열안정성·분해) — 2/3 착지:**
- ✅ **표면장력**(계면활성 축) — 착지(§6.2).
- ✅ **Tg trend**(유연성 축) — 착지(§6.2).
- ❌ **열안정성(Td)** — QSPR no-go(§9). 시뮬 아닌 지식층으로만 유지.
- 파생 백로그: CG 티어(점탄성·네트워크 역학) / 반응성 커스텀 MTP("새 미션"급) / 변종 스크리닝·역설계(Phase 3 병렬 위 장기 후보).

---

## 9. 경계 — MD/우리가 안 하는 것 & 왜 (단일 출처)
> "MD 밖"은 막연한 판단이 아니라 **결합 못 만듦·크기 한계·전자구조 밖·데이터 벽**이라는 물리·데이터 이유이고, 대부분 실제로 부딪혀 확인함. 전무 보고용 상세 = `docs/md-service-scenario.md`.

- 🔴 **점도(viscosity) = MD 경로 불가 확정** (Track B, 2026-07-24). Green-Kubo + cepstral로 **20h GPU·3점 Arrhenius** 검정 → 두 축 모두 FAIL: ① **절대값** η_cep가 전 온도서 앵커의 **~1/8**(≈8× 과소, "저온 절단" 가설 반증) ② **T-트렌드** 겉보기 Eη≈**5.6 kJ/mol** vs 실측 **13.3–14.5**(~2.5× 평평)→ 상대 η(T)도 오도. 병목은 분산이 아님(cepstral로 σ 1.7%까지 해소) — **PCFF/NVT-GK 점도 물리 자체**("precisely-wrong"). ⇒ "MD 점도 불가"는 정량 근거로 확정 인용 가능. ★ 생존: **cepstral = 검증된 분산감소 추정자**(방법론 자산이나 PDMS 점도는 못 구함) · 고정-T 변종 순위는 미검증 별도 축. 정본 메모리 `delta-learning-transport-viscosity`·`viscosity-spike-status`.
- ⛔ **MLIP 힘장대체 = 종결 NO** (2026-07-13). ① MACE-MP-0 밀도 탈락(+11.2%) → 무기-PBE 참조클래스(MatterSim/Orb-v3/SevenNet) 일괄 배제 ② 후속 밀도 스크린 MACE·OrbMol no-go, AIMNet2 tie ③ 가스 Widom Gate1 = NO-GO(**UMA가 Ar-실록산을 DFT 대비 +23% 과결합**, PCFF는 DFT와 일치). ⇒ **패배는 힘장 우열이 아니라 siloxane OOD**(PDMS는 chemistry+form-factor 이중 OOD). 비-Si 유기계면이면 MLIP 경쟁력 가능 — **실록산 벌크엔 현재 진입로 없음.** provenance(force_field/method) 계약은 미래 엔진 진입 자산으로 유지.
- ❌ **Huang Class II = 계획 제외** (2026-07-10 사용자 결정). 2025 JPCB 벤치마크 PDMS 밀도 1등(RMSE 0.010)이나 밀도 외 물성(CTE·δD — 정작 아쉬운 축) 우위 미증명 + LUNAR 미지원 이식·검증 비용 대비 근거 부족. 정밀도 업그레이드 축은 MLIP로 일원화. **재제안 금지.**
- ❌ **OPLS = 금지**: Si 파라미터 없어 PDMS 부적합(밀도 엉뚱하게 나옴).
- ❌ **열안정성(Td) = QSPR no-go**(2026-07-09): Si가 OOD + PDMS Td 다중값 앵커. 내열성 지배변수=말단기. 반응성 연구과제.
- 🔴 **혼합물 "밀도" = 값어치 낮음**(Gate-0, f91aae5): PCFF 계통 밀도오차 ≫ excess ≫ 노이즈(hexane −8.6% / EA +3.9% 부호 반대). "실험 순물질값 + ideal-mixing"이 PCFF 혼합물-MD를 이김. 혼합물 MD의 값어치는 이상혼합에서 수십% 벗어나는 축에 있음.
- ⚠ **화학반응·경화·충전(필러)·유화 제품군 = MD 범위 밖**(결합 생성 불가 / 나노 스케일 초과). 상세 = `docs/md-service-scenario.md` §4.

---

## 10. 운영 · git · 워킹트리 (다른 세션 필수 인지)
**git / 푸시:**
- 커밋/푸시는 **사용자 명시 요청 시에만**(정책). 미푸시 커밋 존재 — `git rev-list --count origin/main..HEAD`로 확인, 푸시는 사용자 담당(GitLab, `http.sslCAInfo` CA 번들 필요).
- ⚠ **다중 세션이 git index 하나를 공유** — 커밋은 반드시 명시 경로(`git commit -- <paths>`)로. 아니면 다른 세션 스테이징을 쓸어감(실제 사고 있었음).
- 서버 코드·혼합물·폴리머 입력 = 전부 커밋됨(main). untracked 잔재: 혼합물/structure-endpoint spec·plan 일부 미커밋 · 교육자료 `docs/education/`(단일소스) · 로그류(`*.restart.log`·`log.lammps` = 커밋 금지).

**운영 주의:**
- ⚠ **전체스택 테스트 전 이전 세션 celery/uvicorn 정리 필수** — 공용 박스라 같은 Redis/Oracle 큐를 가로챔. worker는 `--concurrency=1`. **`pkill -f`로 자기 패턴 죽이지 말 것**(셸 자살).
- 부팅 시 stranded `running` 잡 자동 조정 착지(ebe420f) ⇒ 수동 정리 불필요.
- 테스트는 **라이브 dev Oracle 직결**(sqlite 전환 금지 — prod parity). 새 Job 컬럼은 라이브 ALTER 선행해야 그린. Oracle dev 70.11.10.22/KAIS, python-oracledb **THICK 모드**.
- 🔴 **라이브 스택 = 워킹트리 스냅샷**(프로세스 기동 시점 파일). 커밋해도 **재기동 전엔 라이브에 안 들어간다** ⇒ 착지 후 "배포됨"이라 쓰기 전에 `pgrep -af uvicorn`의 기동시각과 `git log`를 대조할 것. 역으로, 기동 시 워킹트리에 **미커밋 변경이 있으면 그것도 같이 라이브로 나간다**(2026-08-06 08:02 배포 실례).
  - **현재 라이브 = `2308745` 스냅샷**(2026-08-07 00:53 UTC 재배포 · `server/safe-redeploy.sh`). 드리프트 없음. 직전 08-06 08:02 스냅샷이 안고 있던 갭(Track D `resolve.py` 반복 수렴 미반영 등)은 이 재배포로 해소.
  - ⚠ **`tmux send-keys`로 재기동 명령을 넣지 말 것**(2026-08-07 실측 함정): 스택 실행 중인 pane은 `run-dev.sh`(uvicorn)가 **포그라운드**라 키 입력이 셸이 아니라 uvicorn stdin으로 간다 — 명령이 조용히 안 돌고, tty 버퍼에 남았다가 셸이 프롬프트로 돌아오는 순간 **뒤늦게 실행돼 이중 기동**을 낸다. 재배포는 **새 tmux 창**에서 `safe-redeploy.sh`를 돌릴 것(구 창은 스크립트가 정리).
- 라이브 서버 = **상시 가동**(APIS 프론트가 `70.11.11.234:8000` 소비 중 — 옛 "평소 내려둠" 운용 아님). 재기동 `GPU_COUNT=1 bash server/run-dev.sh`(API key off). 절차 = 워커 warm shutdown(SIGINT) → uvicorn/스크립트 종료 → **포트·워커 해제 확인**(run-dev.sh가 잔재 있으면 기동 거부) → 기동. 재기동 전 `curl /jobs/active`로 진행 잡 확인.
- ⚠ **GPU 선택**: `simulate.py` GPU0 하드코딩 수정됨(13f100b — `CUDA_VISIBLE_DEVICES` 먹힘). **단 워커별 GPU 핀은 Phase 3 미구현**이라 기본 단일워커는 GPU0을 씀 ⇒ **긴 MD 전 `pgrep lmp`로 타 세션 확인**(동시 MD가 한 장에 몰리면 타임아웃사). 스파이크는 `SPIKE_GPU=1`.
- ⚠ **LAMMPS 타임아웃**: `_run_lmp`는 진행-기반 stall 타임아웃 + abs_max(prod 5100s). 잡 수명 = celery `task_time_limit=5700`은 잔재, per-task `time_limit=budget+300`으로 해소. 진짜 제약은 **큐 독점**(concurrency=1) → 해법 = Phase 3 worker-per-GPU.
- 통지 표준 메일 **jinpkim@kccworld.co.kr** — gmail(kccitmat@) **금지**(userEmail 컨텍스트에 떠도 무시).

---

## 11. 용어 사전 (모르는 용어 여기서 찾기)
> 연구/화학 배경 없는 IT 개발자 기준. 익숙할 소프트웨어 용어(FastAPI·Celery·Redis·Pydantic·웹훅 등)는 생략.

### 11.1 큰 그림
- **MD (분자동역학)** — 원자 하나하나에 물리 법칙(힘→가속도→이동)을 걸어 짧은 간격으로 반복 계산하는 **"가상 실험실"**. 밀도 같은 물성을 숫자로 뽑는다. 실험 대체가 아니라 보완.
- **PDMS (폴리디메틸실록산)** — KCC의 대표 **실리콘 고무/오일**. 이 프로젝트가 물성을 맞혀 보는 대상.
- **폴리머 / 고분자** — 같은 부품(모노머)이 사슬처럼 길게 반복 연결된 거대 분자. (비유: 같은 구조체가 링크드리스트로 이어진 것.)
- **힘장 (Force Field, FF)** — "이 원자와 저 원자는 이만큼 밀고/당긴다"를 정한 **수식+상수 묶음** = MD의 물리 규칙표. 어떤 힘장이냐로 정확도가 갈린다.
- **MLIP (기계학습 원자간 퍼텐셜)** — 힘장을 사람 손 수식 대신 **AI로 학습**시킨 차세대 버전(OrbMol·AIMNet2·MACE). 이 프로젝트의 **"숫자 정확도" 축**(≠ 설명 담당 LLM).
- **APIS** — 이 서버를 호출하는 **사내 클라이언트 시스템**(종전 ChemStudio 표기 대체).

### 11.2 분자량 / 사슬길이 — 밀도 비교의 핵심 함정
- **mer / 10mer** — 반복 부품이 몇 개 이어졌나. 10mer = 부품 10개짜리 사슬.
- **MW (분자량)** — 분자 하나의 무게. **밀도가 분자량에 따라 달라져** 실험값과 비교하려면 반드시 맞춰야 공정 → **"MW-matched"**.
- **bulk 밀도** — 아주 긴 실제 대량 제품의 밀도(목표 0.965). 짧은 시뮬 모델(10mer) 값과 직접 비교 금지(그래서 MW-matched 0.918로 비교).
- **cSt (센티스토크스)** — 점도 단위. 실리콘 등급 표시(5cSt=묽음). 점도로 대략의 분자량을 가늠.
- **Gelest DMS-T05** — 밀도 비교에 쓴 상용 PDMS 제품(약 5cSt).

### 11.3 파이프라인 도구·단계
- **SMILES** — 분자 구조를 **텍스트 한 줄**로 적는 표기(물 = `O`). 파이프라인 입력.
- **RDKit** — SMILES → **3D 원자 좌표** 생성 라이브러리.
- **Packmol** — 분자 여러 개를 박스에 **겹치지 않게 채우는** 도구.
- **atom typing (원자 타이핑)** — 각 원자가 힘장에서 어떤 "타입"인지 라벨 붙이는 단계. 틀리면 힘 계산이 통째로 어긋나는데 **에러 없이 조용히** 틀림 → 사람이 숫자로 확인.
- **LUNAR** — 원자 타이핑 + LAMMPS 입력파일 생성 도구. (실록산 Si `s_m→sio` 버그를 이 프로젝트에서 패치.)
- **all2lmp / pcff.frc / LAMMPS data** — 힘장 파라미터(`pcff.frc`)를 붙여 LAMMPS가 읽을 입력 데이터로 변환.
- **LAMMPS** — 실제 MD를 돌리는 **엔진**. GPU 가속하는 유일한 도구.
- **NPT / NVT** — 시뮬 조건. NPT = 원자수·압력·온도 고정 → 부피 변하며 **평형 밀도**. NVT = 부피 고정(기체 삽입 계산 등).
- **주기 박스** — 상자를 벽 없이 **무한 반복** 처리. 치수가 빠지면 밀도가 통째로 틀어짐.

### 11.4 힘장 이름들
- **PCFF** — Si 지원 힘장(class2 계열). **지금 파이프라인이 쓰는 것**.
- **class2** — 힘장 수식의 한 계열(더 정교한 항 포함). PCFF·COMPASS가 여기 속함.
- **OPLS** — 다른 힘장. Si 파라미터 없어 PDMS 부적합 → 금지(§9).
- **실록산 (siloxane)** — `Si-O-Si` 결합 = 실리콘 고분자의 뼈대.
- **IFF** — PCFF 변형 힘장군. LUNAR에 타이핑 버그가 아직 남아있음.

### 11.5 물성 이름 (신뢰도 정책과 함께)
> 절대값 = 밀도·열팽창 / 양호 = CED·HSP·기체용해도 / 트렌드만 = 확산·Tg·표면장력·체적탄성률·기체투과.
- **밀도 (g/cm³)** — 단위 부피당 질량. 1차 검증 목표(MW 770~2000 4점 −2.7~−3.7% PASS).
- **열팽창계수 (CTE, α_V)** — 온도가 오를 때 부피가 얼마나 늘어나는지(low — PCFF 한계).
- **CED (응집에너지밀도)** — 분자끼리 얼마나 강하게 뭉치는지.
- **HSP (한센 용해도 파라미터)** — 어떤 용매에 잘 녹는지 지표. 분산(δD)·극성(δP)·수소결합(δH).
- **기체 용해도** — 고분자에 기체(He/Ar/O₂/N₂)가 얼마나 녹는지. 막 소재 평가 기초.
- **Widom 입자삽입** — 평형 박스에 기체를 **가상으로 수없이 "꽂아보며"** 들어가기 쉬운 정도(μ_ex)를 재는 통계 기법. 박스를 안 바꿔 기존 궤적 재활용(offline).
- **표면장력 (γ, mN/m)** — 액체 표면이 오므라들려는 힘(젖음성 좌우). **슬랩**(공기 노출 액막)의 압력 방향차로 잰다. 트렌드.
- **슬랩 (slab)** — 상자에 액체를 판처럼 깔고 위아래를 비워 **표면을 일부러 만든** 구조. ⚠ bulk용 테일보정 무효.
- **체적탄성률 (K, GPa)** — 사방에서 눌렀을 때 안 찌그러지는 정도(=κ_T의 역수). NPT 부피 요동으로 잰다. 트렌드.
- **기체 투과 (P, Barrer)** — 막을 통해 기체가 새는 정도. **P = 용해도 S × 확산 D**. 미가교 melt라 트렌드. 방벽·분리막 소재 지표. (9번째 물성, 2026-07-30 등록.)
- **점도 (η, mPa·s)** — 끈적임. **Green-Kubo** = 평형서 응력의 시간 "기억"(자기상관)을 적분. 흐르게 강제 안 하고 잰다. 🔴 **판정: MD 불가 확정**(§9).
- **확산계수** — 분자가 얼마나 빨리 퍼지는지. 트렌드만.
- **Tg (유리전이온도)** — 딱딱한 유리 ↔ 말랑한 고무로 바뀌는 온도. 트렌드만(MD 냉각속도가 실험보다 10¹⁰배 빨라 절대값 높게 나옴). 냉각하며 밀도-온도 곡선이 꺾이는 지점(kink)을 찾는다.

### 11.6 시뮬 품질·통계
- **검증 관문** — 에러는 안 나지만 **조용히 틀릴 수 있는 지점**을 숫자로 확인하는 체크포인트.
- **unassigned 타입** — 타이핑서 타입 못 받은 원자. **0개여야 정상**.
- **SEM** — 결과가 얼마나 흔들리는지(불확실성). 작을수록 안정적.
- **n_tail** — 평균 낼 때 쓴 시뮬 후반부(평형 후) 샘플 수.
- **sanity rail** — "말이 되는 범위인지"만 거르는 느슨한 상·하한 경고선.
- **replicas** — 같은 조건으로 여러 번 독립 시뮬 후 평균.
- **평형 (equilibrium)** — 시뮬이 충분히 안정돼 값이 정착한 상태. 미달이면 계통 오차.
- **테일 보정** — 컷오프 밖 분자간 인력을 해석적으로 보충. ⚠ 균질 bulk 가정이라 계면(슬랩)엔 무효.

### 11.7 인프라·빌드
- **GPU / RTX 6000 Ada / ADA89 / compute 8.9** — 연산 가속 그래픽카드와 세대 코드. LAMMPS를 이 GPU에 맞춰 빌드.
- **KOKKOS + CUDA** — LAMMPS를 GPU에서 돌리는 가속 라이브러리 + NVIDIA 실행 계층(그래서 `-sf kk`, `-sf gpu` 아님).
- **tmux** — 터미널 세션을 백그라운드로 살려두는 도구(SSH 끊겨도 긴 시뮬 생존).
- **conda / md_env / Miniforge** — 파이썬 환경 관리 도구 + 이 프로젝트 전용 환경.

### 11.8 소프트웨어 — 프로젝트 특수 용어
- **MCP** — LLM이 외부 도구를 표준 방식으로 호출하게 하는 규약.
- **shadow** — 새 로직을 실제 반영 없이 뒤에서 병행 실행해 결과만 비교.
- **best-effort / degraded** — 되면 하고 안 되면 건너뛰되 전체는 안 죽이는 처리 / LLM이 죽어도 숫자는 계속 내보내는 축소 동작.
- **물질키 / 카탈로그** — 자주 쓰는 물질을 서버에 큐레이션한 사전(`library/catalog.json`).
- **fidelity (충실도)** — 카탈로그 구조 재현도 3단: exact / representative(caveat) / coarse(absolute 물성 low 캡).
- **provenance (계산 이력)** — 이 숫자가 무엇으로 어떻게 나왔는지 기록(힘장·도구·패치상태·MW·구조 출처·게이트·정의버전).
- **caveat** — 신뢰등급에 코드가 붙이는 "이 값 볼 때 주의할 점".
- **(물성) 레시피** — 물성 하나를 뽑는 절차 묶음(프로토콜+분석+게이트+시간예산). "물성 추가 = 코어 수정 없이 레시피 등록"이 실증된 구조(`md/recipes.py`, 현재 9종).
- **멀티엔진 / engine_kind** — 물성을 MD 외 **GC(그룹기여)·QSPR(학습모델)** 1초 동기 엔진으로도 계산(`app/engines/`). `engine="auto"`가 (물성,구조) 보고 고르되 **Si는 MD 폴백**. 비-MD=trend 고정. provenance에 engine_kind(MD·GC·QSPR·DB) 스탬프. (§6.5)
- **혼합물 / 성분** — 여러 물질을 물리적으로 섞은 계. `components[]`(각 SMILES + 질량분율 + role). ⚠ 화학반응·경화는 범위 밖(§9).
- **census (조성 검증 게이트)** — 상자를 채운 뒤 실제 들어간 분자를 세어 요청 조성과 맞는지 확인(union-find). 조용히 틀리는 지점.
- **등급 그리드** — 신뢰등급을 (물성×화학가족) 셀 단위로 관리하는 표.
- **trust_verdict** — 등급·게이트·신호를 모아 사용자에게 한 줄로 "믿어도 되는지" 알려주는 결정론 판정(코드가 정함).
- **OOD (분포 밖)** — AI 모델이 학습서 못 본 종류의 입력. 여기선 MLIP들이 실록산을 거의 안 봐서 틀린 게 핵심 — 모델이 나빠서가 아니라 우리 물질이 그들 분포 밖.
- **preflight** — 접수 시점에 입력·규모·시간을 사전 검사해 비현실적 잡을 계산 전 거부.
- **검증 원장 / 보정층** — 잡마다 (시뮬값,실험값)을 기록하는 테이블(`TAP_MD_VALID`) / 거기 쌓인 계통오차로 사후 보정하는 층(원본 불변, N<3이면 abstain).
- **앵커 (실험 앵커)** — 신뢰·보정의 기준이 되는 큐레이션 실험 측정값(`references.json`). MW-매칭이 핵심 규율.

---

## 부록 A. TAP_MD_STRUCTURE — prod 마이그레이션 (3D 구조 아티팩트)
dev는 `create_all`이 자동 생성했으나 **운영은 수동 DDL 필요**(선례: `TAP_MD_JOB.SMILES` nullable ALTER). ⚠ PK 제약을 **명명**할 것(dev의 `create_all`은 `sys_c00…` 시스템 명명).

```sql
CREATE TABLE TAP_MD_STRUCTURE (
  JOB_ID         VARCHAR2(36 CHAR) NOT NULL,
  PAYLOAD        BLOB              NOT NULL,   -- gzip된 JSON. 실측 최대 ~125KB
  FORMAT_VERSION NUMBER            NOT NULL,   -- =1. 포맷 진화 시 프런트 협상 + ETag 무효화
  N_ATOMS        NUMBER            NOT NULL,   -- BLOB 안 열고 규모 감시
  CREATED_AT     DATE              NOT NULL,
  CONSTRAINT PK_TAP_MD_STRUCTURE PRIMARY KEY (JOB_ID)
);
```
⚠ 저장 payload를 재생성하는 모든 수정은 `FORMAT_VERSION`을 **반드시** 올릴 것 — 안 올리면 ETag(`{job_id}-{format_version}`)가 같아 클라이언트가 틀린 구조를 무기한 유지. 재생성 = 해당 행 DELETE → 다음 GET의 지연생성이 재영속화.
